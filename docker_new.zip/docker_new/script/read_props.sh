#!/bin/bash
if [ $# -ne 3 ]; then
	echo "Error: Number of arguments not equal to 3"
	#echo "Info: Expecting 1 arguments, arg1 = application properties path"
	exit 1
fi
WORK_DIR=$1
PROP_FILE=$2
DOCK_TEMP=$3

while IFS='=' read -r k v; do
	echo "Replacing variable in docker template" $k " With value " $v
	sed -i "s/$k/$v/g" $WORK_DIR/$DOCK_TEMP
done < $WORK_DIR/$PROP_FILE
echo "Docker File created Successfully and placed at " $WORK_DIR "and Docker File Name is:" $DOCK_TEMP
