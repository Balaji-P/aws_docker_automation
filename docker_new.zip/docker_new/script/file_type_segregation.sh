#!/bin/bash

if [ $# -ne 2 ]; then
	echo "Error: Number of arguments not equal to 2"
	echo "Info: Expecting 2 arguments, arg1 = project working directory, arg2 = Docker file template directory"
	exit 1
fi

dir_name="$1"
docker_temp_dir=$2
#extn="$2"
#search_extn="*.""$extn"

segregate_files() {

	find "$dir_name" -type f | sed -n 's/..*\.//p' | sort | uniq -c > seg_file.txt
	echo "Details of file extensions inside directory "$dir_name" and corresponding counts are written to file "seg_file.txt""
}

find_files() {
	find "$dir_name" -type f -name "$search_extn" > file_details.txt
	echo "Details of files with extension "$search_extn" inside "$dir_name" are written to file "file_details.txt""
}


if [ -d "$dir_name" ]; then

	segregate_files
	#find_files
	if [ $? -eq 0 ]; then
		sh ./create_docker_file.sh $dir_name $docker_temp_dir
	fi
else
	echo "Error: Directory $dir_name does not exists!!"
	exit 1
fi
